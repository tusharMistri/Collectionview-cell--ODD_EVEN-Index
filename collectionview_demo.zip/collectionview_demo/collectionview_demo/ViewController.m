//
//  ViewController.m
//  collectionview_demo
//
//  Created by Tushar on 07/12/17.
//  Copyright © 2017 tushar. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    Customcell1 *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"Customcell1" forIndexPath:indexPath];
    cell.labelName.text = [NSString stringWithFormat:@"%ld",(long)indexPath.row];
    cell.labelAddress.text = @"Address";
    return cell;
}



-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return 50;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    //    int widht = indexPath.row % 3 ? collectionView.frame.size.width / 2 : collectionView.frame.size.width;
    int widht = indexPath.row % 3;
    //    ? collectionView.frame.size.width : collectionView.frame.size.width/2;
    if (widht == 0)
    {
        return CGSizeMake(collectionView.frame.size.width ,100);
    }
    else
    {
        return CGSizeMake(collectionView.frame.size.width/2 ,100);
    }
}



-(void)collectionView:(UICollectionView *)collectionView willDisplayCell:(UICollectionViewCell *)cell forItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row % 2 == 0)
    { //change the "%2" depending on how many cells you want alternating.
        UIColor *altCellColor = [UIColor colorWithRed:255/255.0 green:237/255.0 blue:227/255.0 alpha:1.0]; //this can be changed, at the moment it sets the background color to red.
        cell.backgroundColor = altCellColor;
    }
    else {
        UIColor *altCellColor2 = [UIColor colorWithRed:1 green:1 blue:1 alpha:1.0]; //this can be changed, at the moment it sets the background color to white.
        cell.backgroundColor = altCellColor2;
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}


@end
