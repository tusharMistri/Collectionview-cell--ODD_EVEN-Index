//
//  Customcell1.m
//  collectionview_demo
//
//  Created by Tushar on 07/12/17.
//  Copyright © 2017 tushar. All rights reserved.
//

#import "Customcell1.h"

@implementation Customcell1

@end
