//
//  Customcell1.h
//  collectionview_demo
//
//  Created by Tushar on 07/12/17.
//  Copyright © 2017 tushar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Customcell1 : UICollectionViewCell

@property (strong ,nonatomic) IBOutlet UILabel *labelName;
@property (strong ,nonatomic) IBOutlet UILabel *labelAddress;

@end
