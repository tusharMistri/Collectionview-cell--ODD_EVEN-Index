//
//  ViewController.h
//  collectionview_demo
//
//  Created by Tushar on 07/12/17.
//  Copyright © 2017 tushar. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Customcell1.h"

@interface ViewController : UIViewController <UICollectionViewDelegate , UICollectionViewDataSource>


@end

